from django.apps import AppConfig


class UserDetailsConfig(AppConfig):
    name = 'user_details'
